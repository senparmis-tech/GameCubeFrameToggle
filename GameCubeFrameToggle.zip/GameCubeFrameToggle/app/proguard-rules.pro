# Shizuku — keep all Shizuku classes so reflection-based IPC works
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }

# Keep app receiver/service classes
-keep class com.gamecube.frametoggle.** { *; }
