package com.gamecube.frametoggle.shizuku

import android.content.Context
import android.content.SharedPreferences

/**
 * Centralized SharedPreferences access for persisting toggle state and user settings.
 * Used by both the MainActivity and the TileService to stay in sync.
 */
object PrefsHelper {

    private const val PREFS_NAME = "frame_toggle_prefs"
    private const val KEY_IS_ENABLED = "is_enabled"
    private const val KEY_APPLY_AT_BOOT = "apply_at_boot"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Whether the frame interpolation is currently toggled ON. */
    fun isEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_IS_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_IS_ENABLED, enabled).apply()
    }

    /** Whether the user wants the setting re-applied after boot. */
    fun isApplyAtBoot(context: Context): Boolean =
        prefs(context).getBoolean(KEY_APPLY_AT_BOOT, false)

    fun setApplyAtBoot(context: Context, apply: Boolean) {
        prefs(context).edit().putBoolean(KEY_APPLY_AT_BOOT, apply).apply()
    }
}
