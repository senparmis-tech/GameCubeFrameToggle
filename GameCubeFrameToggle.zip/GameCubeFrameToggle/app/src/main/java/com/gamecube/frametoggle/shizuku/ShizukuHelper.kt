package com.gamecube.frametoggle.shizuku

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuRemoteProcess

/**
 * Helper object that wraps all Shizuku interactions.
 * Provides a clean API for checking state and running shell commands.
 */
object ShizukuHelper {

    private const val TAG = "ShizukuHelper"
    private const val REQUEST_CODE = 1001

    // The exact setting key used by iQOO/vivo for SR frame interpolation
    const val SETTING_KEY = "gamecube_frame_interpolation_for_sr"

    // Value that enables 120Hz frame interpolation
    const val SETTING_VALUE_ON = "1:2::60:120"

    /**
     * Returns true if the Shizuku service is running and reachable.
     */
    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Exception) {
            Log.w(TAG, "Shizuku binder not available: ${e.message}")
            false
        }
    }

    /**
     * Returns true if this app already has Shizuku permission granted.
     */
    fun hasPermission(): Boolean {
        return try {
            if (Shizuku.isPreV11()) {
                // Legacy permission model (Shizuku < v11) — not relevant for API 13 but safe fallback
                false
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (e: Exception) {
            Log.w(TAG, "Permission check failed: ${e.message}")
            false
        }
    }

    /**
     * Requests Shizuku permission. The result is delivered to the
     * Shizuku.OnRequestPermissionResultListener registered in the calling component.
     */
    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to request Shizuku permission: ${e.message}")
        }
    }

    /**
     * Enables the GameCube SR frame interpolation setting.
     * Runs: settings put system gamecube_frame_interpolation_for_sr 1:2::60:120
     *
     * @return Result wrapping success message or an exception.
     */
    fun enableFrameInterpolation(): Result<String> {
        return runCommand("settings put system $SETTING_KEY $SETTING_VALUE_ON")
    }

    /**
     * Disables the GameCube SR frame interpolation setting.
     * Runs: settings delete system gamecube_frame_interpolation_for_sr
     *
     * @return Result wrapping success message or an exception.
     */
    fun disableFrameInterpolation(): Result<String> {
        return runCommand("settings delete system $SETTING_KEY")
    }

    /**
     * Reads the current value of the setting.
     * Runs: settings get system gamecube_frame_interpolation_for_sr
     *
     * @return The raw string value, or null if the setting doesn't exist / command fails.
     */
    fun getCurrentValue(): String? {
        val result = runCommand("settings get system $SETTING_KEY")
        return result.getOrNull()?.trim()?.takeIf {
            it.isNotEmpty() && it != "null"
        }
    }

    /**
     * Checks if the setting is currently in the ON state.
     */
    fun isEnabled(): Boolean {
        val value = getCurrentValue()
        return value == SETTING_VALUE_ON
    }

    /**
     * Executes an arbitrary shell command via Shizuku's remote process.
     * This method is synchronous — call it from a background thread.
     *
     * @param command The shell command to execute (without "sh -c" wrapping).
     * @return Result<String> containing stdout on success, or an exception on failure.
     */
    fun runCommand(command: String): Result<String> {
        if (!isShizukuAvailable()) {
            return Result.failure(IllegalStateException("Shizuku is not running. Please open the Shizuku app and start the service."))
        }
        if (!hasPermission()) {
            return Result.failure(SecurityException("Shizuku permission not granted. Please authorize this app in Shizuku."))
        }

        return try {
            Log.d(TAG, "Executing: $command")

            // Build the process via Shizuku's remote execution
            val process: ShizukuRemoteProcess = Shizuku.newProcess(
                arrayOf("sh", "-c", command),
                null,  // environment (inherit)
                null   // working directory (inherit)
            )

            // Read stdout
            val stdout = process.inputStream.bufferedReader().readText().trim()
            // Read stderr for error detection
            val stderr = process.errorStream.bufferedReader().readText().trim()

            val exitCode = process.waitFor()
            process.destroy()

            Log.d(TAG, "Exit: $exitCode | stdout: $stdout | stderr: $stderr")

            if (exitCode == 0) {
                Result.success(stdout)
            } else {
                Result.failure(RuntimeException("Command failed (exit $exitCode): $stderr"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "runCommand exception: ${e.message}", e)
            Result.failure(e)
        }
    }
}
