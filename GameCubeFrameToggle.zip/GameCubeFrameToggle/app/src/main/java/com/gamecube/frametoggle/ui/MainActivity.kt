package com.gamecube.frametoggle.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gamecube.frametoggle.databinding.ActivityMainBinding
import com.gamecube.frametoggle.shizuku.PrefsHelper
import com.gamecube.frametoggle.shizuku.ShizukuHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

/**
 * Main activity — shows toggle, apply-at-boot checkbox, and Shizuku status.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Shizuku permission result listener
    private val shizukuPermissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                updateUi()
                showToast("Shizuku permission granted!")
            } else {
                showToast("Shizuku permission denied. The app cannot function without it.")
            }
        }

    // Called when Shizuku service binds or unbinds
    private val shizukuBinderReceivedListener = Shizuku.OnBinderReceivedListener {
        updateUi()
    }
    private val shizukuBinderDeadListener = Shizuku.OnBinderDeadListener {
        updateUi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Register Shizuku listeners before anything else
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        Shizuku.addBinderReceivedListenerSticky(shizukuBinderReceivedListener)
        Shizuku.addBinderDeadListener(shizukuBinderDeadListener)

        setupClickListeners()
        updateUi()
    }

    override fun onResume() {
        super.onResume()
        // Refresh state every time the user comes back (e.g., after opening Shizuku app)
        updateUi()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        Shizuku.removeBinderReceivedListener(shizukuBinderReceivedListener)
        Shizuku.removeBinderDeadListener(shizukuBinderDeadListener)
    }

    private fun setupClickListeners() {
        // Main toggle switch
        binding.switchToggle.setOnCheckedChangeListener { _, isChecked ->
            // Only react to user interaction, not programmatic changes
            if (binding.switchToggle.isPressed) {
                performToggle(isChecked)
            }
        }

        // Apply-at-boot checkbox
        binding.checkboxApplyAtBoot.setOnCheckedChangeListener { _, isChecked ->
            PrefsHelper.setApplyAtBoot(this, isChecked)
        }

        // Grant Shizuku permission button
        binding.btnGrantShizuku.setOnClickListener {
            if (ShizukuHelper.isShizukuAvailable()) {
                ShizukuHelper.requestPermission()
            } else {
                // Shizuku not running — offer to open the app
                tryOpenShizukuApp()
            }
        }

        // Open Shizuku app button
        binding.btnOpenShizuku.setOnClickListener {
            tryOpenShizukuApp()
        }
    }

    /**
     * Reads actual device state from Shizuku (background thread),
     * then updates all UI elements on the main thread.
     */
    private fun updateUi() {
        val shizukuAvailable = ShizukuHelper.isShizukuAvailable()
        val hasPermission = ShizukuHelper.hasPermission()

        if (!shizukuAvailable) {
            runOnUiThread { showShizukuNotRunning() }
            return
        }

        if (!hasPermission) {
            runOnUiThread { showShizukuNeedsPermission() }
            return
        }

        // Read actual device setting on background thread
        lifecycleScope.launch {
            binding.progressBar.visibility = View.VISIBLE
            val isEnabled = withContext(Dispatchers.IO) {
                ShizukuHelper.isEnabled()
            }
            // Sync prefs with real device state
            PrefsHelper.setEnabled(this@MainActivity, isEnabled)

            binding.progressBar.visibility = View.GONE
            showConnectedState(isEnabled)
        }
    }

    /**
     * Performs the toggle action (enable/disable) on a background thread.
     */
    private fun performToggle(enable: Boolean) {
        lifecycleScope.launch {
            binding.switchToggle.isEnabled = false
            binding.progressBar.visibility = View.VISIBLE
            binding.tvStatus.text = if (enable) "Enabling…" else "Disabling…"

            val result = withContext(Dispatchers.IO) {
                if (enable) ShizukuHelper.enableFrameInterpolation()
                else ShizukuHelper.disableFrameInterpolation()
            }

            binding.progressBar.visibility = View.GONE
            binding.switchToggle.isEnabled = true

            result.fold(
                onSuccess = {
                    PrefsHelper.setEnabled(this@MainActivity, enable)
                    showConnectedState(enable)
                    val msg = if (enable) "120Hz interpolation: ON" else "120Hz interpolation: OFF"
                    showToast(msg)
                },
                onFailure = { e ->
                    // Revert the switch since the command failed
                    binding.switchToggle.isChecked = !enable
                    binding.tvStatus.text = "Error: ${e.message}"
                    showToast("Failed: ${e.message}")
                }
            )
        }
    }

    // ── UI state helpers ──────────────────────────────────────────────────────

    private fun showConnectedState(isEnabled: Boolean) {
        binding.groupShizukuPrompt.visibility = View.GONE
        binding.groupMainControls.visibility = View.VISIBLE

        binding.tvShizukuStatus.text = "● Shizuku: Connected"
        binding.tvShizukuStatus.setTextColor(getColor(android.R.color.holo_green_dark))

        // Update switch without triggering the listener
        binding.switchToggle.setOnCheckedChangeListener(null)
        binding.switchToggle.isChecked = isEnabled
        binding.switchToggle.setOnCheckedChangeListener { _, checked ->
            if (binding.switchToggle.isPressed) performToggle(checked)
        }

        binding.tvStatus.text = if (isEnabled) "120Hz Frame Interpolation: ON" else "120Hz Frame Interpolation: OFF"
        binding.tvStatus.setTextColor(
            if (isEnabled) getColor(android.R.color.holo_green_dark)
            else getColor(android.R.color.darker_gray)
        )

        binding.checkboxApplyAtBoot.isChecked = PrefsHelper.isApplyAtBoot(this)
    }

    private fun showShizukuNotRunning() {
        binding.groupMainControls.visibility = View.GONE
        binding.groupShizukuPrompt.visibility = View.VISIBLE
        binding.tvShizukuStatus.text = "● Shizuku: Not running"
        binding.tvShizukuStatus.setTextColor(getColor(android.R.color.holo_red_dark))
        binding.tvShizukuPrompt.text =
            "Shizuku is not running.\n\n" +
            "1. Install Shizuku from Play Store\n" +
            "2. Start Shizuku via ADB:\n" +
            "   adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh\n" +
            "3. Tap 'Open Shizuku' below and authorize this app"
        binding.btnGrantShizuku.text = "Open Shizuku App"
        binding.btnGrantShizuku.visibility = View.GONE
        binding.btnOpenShizuku.visibility = View.VISIBLE
    }

    private fun showShizukuNeedsPermission() {
        binding.groupMainControls.visibility = View.GONE
        binding.groupShizukuPrompt.visibility = View.VISIBLE
        binding.tvShizukuStatus.text = "● Shizuku: Permission required"
        binding.tvShizukuStatus.setTextColor(getColor(android.R.color.holo_orange_dark))
        binding.tvShizukuPrompt.text =
            "Shizuku is running but this app needs permission.\n\n" +
            "Tap 'Grant Permission' and authorize in the Shizuku dialog."
        binding.btnGrantShizuku.text = "Grant Permission"
        binding.btnGrantShizuku.visibility = View.VISIBLE
        binding.btnOpenShizuku.visibility = View.VISIBLE
    }

    private fun tryOpenShizukuApp() {
        val shizukuPackage = "moe.shizuku.privileged.api"
        val pm = packageManager
        val intent = pm.getLaunchIntentForPackage(shizukuPackage)
        if (intent != null) {
            startActivity(intent)
        } else {
            // Not installed — open Play Store
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$shizukuPackage")))
            } catch (e: Exception) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$shizukuPackage")))
            }
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
