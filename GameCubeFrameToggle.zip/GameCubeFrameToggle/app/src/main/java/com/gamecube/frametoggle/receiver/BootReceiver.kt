package com.gamecube.frametoggle.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.gamecube.frametoggle.shizuku.PrefsHelper
import com.gamecube.frametoggle.shizuku.ShizukuHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Receives BOOT_COMPLETED and LOCKED_BOOT_COMPLETED.
 * If "Apply at boot" is checked AND the last known state was ON,
 * re-applies the frame interpolation setting via Shizuku.
 *
 * Note: Shizuku must already be running (started via ADB persistent mode)
 * for this to work after boot. Without Shizuku running, the command silently skips.
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.LOCKED_BOOT_COMPLETED") {
            return
        }

        Log.d(TAG, "Boot received: $action")

        val applyAtBoot = PrefsHelper.isApplyAtBoot(context)
        val wasEnabled = PrefsHelper.isEnabled(context)

        if (!applyAtBoot || !wasEnabled) {
            Log.d(TAG, "Skipping boot apply: applyAtBoot=$applyAtBoot, wasEnabled=$wasEnabled")
            return
        }

        Log.d(TAG, "Applying frame interpolation at boot…")

        // Use a coroutine with a pending result to keep the receiver alive
        // while the async Shizuku command completes
        val pendingResult = goAsync()

        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                if (!ShizukuHelper.isShizukuAvailable()) {
                    Log.w(TAG, "Shizuku not available at boot — skipping")
                    return@launch
                }
                if (!ShizukuHelper.hasPermission()) {
                    Log.w(TAG, "Shizuku permission not granted — skipping")
                    return@launch
                }

                val result = ShizukuHelper.enableFrameInterpolation()
                result.fold(
                    onSuccess = { Log.d(TAG, "Boot apply succeeded") },
                    onFailure = { e -> Log.e(TAG, "Boot apply failed: ${e.message}") }
                )
            } finally {
                pendingResult.finish()
            }
        }
    }
}
