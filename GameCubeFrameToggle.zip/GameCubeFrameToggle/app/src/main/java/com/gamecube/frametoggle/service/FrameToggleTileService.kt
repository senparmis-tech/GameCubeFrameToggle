package com.gamecube.frametoggle.service

import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import com.gamecube.frametoggle.R
import com.gamecube.frametoggle.shizuku.PrefsHelper
import com.gamecube.frametoggle.shizuku.ShizukuHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Quick Settings tile that toggles 120Hz frame interpolation with a single tap.
 *
 * Tile label:
 *   "120Hz ON"  — when setting is active   (green / ACTIVE state)
 *   "120Hz OFF" — when setting is inactive (gray  / INACTIVE state)
 *
 * The tile reads the real device value on start so it always reflects truth,
 * not just the last saved preference.
 */
class FrameToggleTileService : TileService() {

    // Scoped to the tile's active lifecycle (startListening → stopListening)
    private var tileScope: CoroutineScope? = null

    // ── TileService lifecycle ─────────────────────────────────────────────────

    override fun onStartListening() {
        super.onStartListening()
        tileScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        refreshTileState()
    }

    override fun onStopListening() {
        super.onStopListening()
        tileScope?.cancel()
        tileScope = null
    }

    /**
     * Called when the user taps the tile.
     */
    override fun onClick() {
        super.onClick()

        val scope = tileScope ?: return

        // Set tile to UNAVAILABLE while the command runs to prevent double-taps
        qsTile?.state = Tile.STATE_UNAVAILABLE
        qsTile?.updateTile()

        scope.launch {
            if (!ShizukuHelper.isShizukuAvailable() || !ShizukuHelper.hasPermission()) {
                showToast("Shizuku not available — open the app to set up")
                refreshTileState()
                return@launch
            }

            val currentlyEnabled = withContext(Dispatchers.IO) {
                ShizukuHelper.isEnabled()
            }
            val newState = !currentlyEnabled

            val result = withContext(Dispatchers.IO) {
                if (newState) ShizukuHelper.enableFrameInterpolation()
                else ShizukuHelper.disableFrameInterpolation()
            }

            result.fold(
                onSuccess = {
                    PrefsHelper.setEnabled(applicationContext, newState)
                    applyTileState(newState)
                    val msg = if (newState) "120Hz interpolation: ON" else "120Hz interpolation: OFF"
                    showToast(msg)
                },
                onFailure = { e ->
                    showToast("Error: ${e.message}")
                    refreshTileState() // restore accurate state
                }
            )
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Reads the real device setting and updates the tile accordingly.
     */
    private fun refreshTileState() {
        tileScope?.launch {
            val isEnabled = if (ShizukuHelper.isShizukuAvailable() && ShizukuHelper.hasPermission()) {
                withContext(Dispatchers.IO) { ShizukuHelper.isEnabled() }
            } else {
                PrefsHelper.isEnabled(applicationContext) // fall back to cached value
            }
            applyTileState(isEnabled)
        }
    }

    /**
     * Updates the tile's visual state (label, icon colour, active/inactive).
     */
    private fun applyTileState(enabled: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = if (enabled) "120Hz ON" else "120Hz OFF"

        // Subtitle available on Android 10+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = if (enabled) "Frame interpolation" else "Tap to enable"
        }

        // Icon: use a single drawable; the OS tints it green (ACTIVE) or gray (INACTIVE)
        tile.icon = Icon.createWithResource(this, R.drawable.ic_tile)
        tile.updateTile()
    }

    private fun showToast(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
    }
}
